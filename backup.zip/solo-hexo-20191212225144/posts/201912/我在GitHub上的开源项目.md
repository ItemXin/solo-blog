title: 我在 GitHub 上的开源项目
date: '2019-12-12 22:41:43'
updated: '2019-12-12 22:41:43'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo-blog](https://github.com/ItemXin/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ItemXin/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ItemXin/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ItemXin/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://blog.olitem.com`](http://blog.olitem.com "项目主页")</span>

东隅 - 东隅已逝，桑榆非晚



---

### 2. [vd](https://github.com/ItemXin/vd) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ItemXin/vd/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ItemXin/vd/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ItemXin/vd/network/members "分叉数")</span>



